from django.shortcuts import render
from django.contrib.auth.decorators import login_required
# Create your views here.

@login_required
def home(request):
    return render(request, 'letter/home.html', {'name': "Yoj"})

@login_required
def letter(request):
    return render(request, 'letter/letter.html')